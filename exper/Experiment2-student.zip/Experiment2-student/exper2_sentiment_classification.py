# -*- coding: utf-8 -*-

import multiprocessing
import re
import numpy as np
import pandas as pd
from string import punctuation

import gensim

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.preprocessing import MinMaxScaler
from nltk.corpus import stopwords
import nltk

import datasets


def clean_data(dataset, stopwords):
    """文本预处理
    :param separate :返回的句子列表是否需要分割的单词:
    :param dataset: 数据集
    :param stopwords: 停用词集合
    :return sentences_list:经过预处理后的句子列表，每个句子构成了一个list
    return sentences_string:经过预处理后的句子列表，每个句子已字符串的形式存放
    e.g., 两个句子 “AAA BBB CC"和“BB DD", sentences_list=[["AAA", "BBB", "CC"], ["BB", "DD"]]
    sentences_string=[["AAA BBB CC"], ["BB DD"]]
    """
    sentences_list = []
    sentences_string = []
    sentence_label= []
    for row in dataset:  # 迭代dataframe，每一行都是一个元组，第0列是索引，第1列是sentence

        sentence = row['text']
        label = row['label']
        sentence_label.append(label)
        # 除去标点符号等非英文字
        sentence_clean = re.sub("[^a-zA-Z]", " ", sentence)
        #按空格分词
        words = sentence_clean.split()
        #删除停用词
        words = [w for w in words if not w in stopwords]
       
        sentences_list.append(words)
        sentences_string.append( " ".join( [word for word in words] ) )
    return sentences_list,sentences_string,sentence_label


def sentence_vector(GoogleModel, sentences):
    """根据训练好的特征矩阵，用word2vec词向量表示句子（平均词向量）
    :param vectors:已经训练好的word2vec模型
    :param sentences:需要使用词向量表示的句子列表
    :return sentence_vectors: 由平均词向量表示的句子列表"""
    sentence_vectors = []
    for sentence in sentences:
        sentence_vec = np.zeros( shape=300 )  # 用0初始化一个30维向量
        word_nums = 0  # 统计该句子中的单词个数，用于求取平均词向量
        for word in sentence:
            # 该模型无法推断不熟悉单词的向量，将模型中不存在的单词向量初始化为0向量
            if word in GoogleModel.key_to_index.keys():    
                sentence_vec=sentence_vec+GoogleModel[word]
       
        sentence_vectors.append( sentence_vec )
    sentence_vectors = np.array( sentence_vectors )
    return sentence_vectors


def print_evaluate_results(predict_labels, test_labels):
    """训练并评估模型
    :param predict_labels:预测标签
    :param test_labels:真实标签"""
    
    

def native_classification_tfidf(train_string, train_label, test_string, test_label):

    print( "\n tf-idf 文本特征提取中......" )
    

def native_classification_word2vec(train_array, train_label, test_array, test_label):

    #朴素贝叶斯

    

def lr_classification_word2vec(train_array, train_label, test_array, test_label):

    #逻辑回归


if __name__ == '__main__':

    

    print( "载入数据中......" )
    train_data, test_data = datasets.load_dataset('imdb', split=['train', 'test'])
    print( "训练集数据长度：", len( train_data ) )
   
    print( "测试集数据长度：", len( test_data ) )
    

    #加载停用词
    nltk.download('stopwords')
    stops = set(stopwords.words('english'))

    print( "\n数据预处理中....." )
    
    train_list,train_string,train_label = clean_data(train_data, stops)
    test_list,test_string,test_label = clean_data(test_data, stops)
    
    print( "预处理后的训练集数据长度：", len( train_string ) )
    print( "预处理后的测试集数据长度：", len( test_string ) )


    print( "\n****基于TF-IDF词向量表示的朴素贝叶斯分类实验****" )

    predict_labels = native_classification_tfidf(train_string, train_label, test_string, test_label)

    print_evaluate_results( predict_labels, test_label)
    
    print( "-" * 12 )
    print( "\n****基于word2vec的文本表示****" )
    print( "\n加载一个已经训练好的词向量" )
    
    GoogleModel = gensim.models.KeyedVectors.load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True,)

    
  


                                         
