#!/bin/env python

import argparse
from itertools import product
import math
import nltk
from pathlib import Path
from preprocess import preprocess


def load_data(train_path):
    """Load train corpora

    Newlines will be stripped out. 

    Args:
        train_path (Path) -- the training corpus to use. 

    Returns:
        The train sets, as lists of sentences.

    """   

    with open(train_path, 'r') as f:
        train = [l.strip() for l in f.readlines()]
    
    return train


class LanguageModel(object):
    """An n-gram language model trained on a given corpus.
    
    For a given n and given training corpus, constructs an n-gram language
    model for the corpus by:
    1. preprocessing the corpus (adding SOS/EOS/UNK tokens)
    2. calculating (smoothed) probabilities for each n-gram

    Also contains methods for calculating the perplexity of the model
    against another corpus, and for generating sentences.

    Args:
        train_data (list of str): list of sentences comprising the training corpus.
        n (int): the order of language model to build (i.e. 1 for unigram, 2 for bigram, etc.).
        laplace (int): lambda multiplier to use for laplace smoothing (default 1 for add-1 smoothing).

    """

    def __init__(self, train_data, n, laplace=1):
        self.n = n
        self.laplace = laplace
        self.tokens = preprocess(train_data, n)
        self.vocab  = nltk.FreqDist(self.tokens)
        



if __name__ == '__main__':
    parser = argparse.ArgumentParser("N-gram Language Model")
    parser.add_argument('--data', type=str, default="Expertment1_dataset.txt",
            help='Location of the data directory containing ')
    parser.add_argument('--n', type=int, default=3,
            help='Order of N-gram model to create (i.e. 1 for unigram, 2 for bigram, etc.)')
    parser.add_argument('--laplace', type=float, default=0.01,
            help='Lambda parameter for Laplace smoothing (default is 0.01 -- use 1 for add-1 smoothing)')
    
    args = parser.parse_args()

    # Load and prepare train/test data
    data_path = Path(args.data)
    train = load_data(data_path)

    print("Loading {}-gram model...".format(args.n))
    lm = LanguageModel(train, args.n, laplace=args.laplace)
    print("Vocabulary size: {}".format(len(lm.vocab)))

    

